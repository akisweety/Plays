Ansible Role - python27
=======================
This role will ensure that python version 2.7 is installed.

Example Playbook
----------------
    - hosts: servers
      roles:
         - kyungw00k.python27

License
-------
BSD

Author Information
------------------
Kyungwook Park
@kyungw00k(twitter, github)
